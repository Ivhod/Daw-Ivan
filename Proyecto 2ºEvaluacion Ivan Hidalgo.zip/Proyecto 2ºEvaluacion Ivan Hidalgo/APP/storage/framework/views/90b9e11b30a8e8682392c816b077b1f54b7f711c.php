

<?php $__env->startSection('cabecera'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

<div style="text-align: center">
    <h1>Factura</h1>
    <p>Fecha: <?php echo e($fecha_emision); ?></p>
    <table border="1px">
        <thead>
            <tr>
                <th>Concepto</th>
                <th>Importe</th>
                <th>Fecha de Pago</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo e($concepto); ?></td>
                <td><?php echo e($importe); ?></td>
                <td><?php echo e($fecha_pago); ?></td>
            </tr>
        </tbody>
    </table>
    <a href="<?php echo e(route('cuotas.index')); ?>" class="btn btn-warning">Volver</a>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\APP\resources\views/cuotas/factura.blade.php ENDPATH**/ ?>