

<?php $__env->startSection('cabecera'); ?>

    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<h1 style="text-align: center">Nueva Tarea</h1>
<form action="/tareas" method="post" enctype="multipart/form-data">
    <div class="form-group">
        <label for="cliente_id">Cliente</label>
        <select class="form-control" name="cliente_id"  required>
          <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($cliente->id); ?>"><?php echo e($cliente->nombre); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <?php echo e(csrf_field()); ?>


      <div class="form-group">
        <label for="user_id">Usuario</label>
        <select class="form-control" name="user_id"  required>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="form-group">
        <label for="nombre">Nombre</label>
        <input type="text" class="form-control" name="nombre" placeholder="Introduce Nombre">
        <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="error-message"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="form-group">
        <label for="telefono">Telefono</label>
        <input type="text" class="form-control" name="telefono" placeholder="Introduce Telefono">
        <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="error-message"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="form-group">
        <label for="descripcion">Descripcion</label>
        <input type="text" class="form-control" name="descripcion" placeholder="Descripcion....">
        <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="error-message"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="form-group">
        <label for="correo">Correo</label>
        <input type="text" class="form-control" name="correo" placeholder="Introduce Correo">
        <?php $__errorArgs = ['correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="error-message"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="form-group">
        <label for="direccion">Direccion</label>
        <input type="text" class="form-control" name="direccion" placeholder="Introduce Direccion">
      </div>
      <div class="form-group">
        <label for="poblacion">Poblacion</label>
        <input type="text" class="form-control" name="poblacion" placeholder=".......">
      </div>
      <div class="form-group">
        <label for="codigoPostal">Codigo Postal</label>
        <input type="text" class="form-control" name="codigoPostal" placeholder="00000">
        <?php $__errorArgs = ['codigoPostal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

          <div class="error-message"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="form-group">
        <label for="provincia">Provincia</label>
        <select class="form-control" name="provincia"  required>
          <?php $__currentLoopData = $provincias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provincia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($provincia->nombre); ?>" ><?php echo e($provincia->nombre); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="form-check">
          <input type="radio" id="estado" name="estado" value="realizada">
          Realizada <br> 
          <input type="radio" id="estado" name="estado" value="cancelada">
          Cancelada<br>
          <input type="radio" id="estado" name="estado" value="pendiente">
          Pendiente<br>
        
      </div>
      <div class="form-group">
        <label for="fechaCreacion">Fecha Creacion</label>
        <input type="text" class="form-control" name="fechaCreacion" placeholder="00/00/0000" value="<?php echo e($date); ?>" readonly>
      </div>
      <div class="form-group">
        <label for="operario">Operario</label>
        <select class="form-control" name="operario"  required>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($user->name); ?>" ><?php echo e($user->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="form-group">
        <label for="fechaRealizacion">Fecha Realizacion</label>
        <input type="date" class="form-control" name="fechaRealizacion" placeholder="00/00/0000">
        <?php $__errorArgs = ['fechaRealizacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

          <div class="error-message"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="form-group">
        <label for="anotacionPos">Anotacion Posterior</label>
        <input type="text" class="form-control" name="anotacionPos" placeholder="..........." readonly>
      </div>
      <div class="form-group">
        <label for="anotacionAnt">Anotacion Anterior</label>
        <input type="text" class="form-control" name="anotacionAnt" placeholder=".........">
      </div>
      <div class="form-group">
        <label for="fichero">Fichero</label>
        <input type="file" class="form-control" name="fichero" placeholder="C/:......">
      </div>

    <input type="submit" value="Crear" name="enviar" class="btn btn-primary">
    <a href="<?php echo e(route('tareas.index')); ?>" class="btn btn-warning">Cancelar</a>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\APP\resources\views/tareas/crearTarea.blade.php ENDPATH**/ ?>