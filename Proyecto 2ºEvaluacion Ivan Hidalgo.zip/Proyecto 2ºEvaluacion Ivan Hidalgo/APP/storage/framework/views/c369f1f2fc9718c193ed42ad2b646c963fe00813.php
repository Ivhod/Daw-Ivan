

<?php $__env->startSection('cabecera'); ?>

<?php $__env->startSection('contenido'); ?>

<h1 style="text-align: center">Nosecaen S.L.</h1>

<h4> Lista de Clientes</h4>
<form action="<?php echo e(route('clientes.index')); ?>" method="get">
  <input type="text" class="my-1"name="texto" value="<?php echo e($texto); ?>">
  <input type="submit" class="btn btn-primary my-1" value="Buscar">
</form>

<table class="table table-striped" style="text-align: center">
    <thead>
      <tr>
        <th hidden scope="col">ID</th>
        <th scope="col">CIF</th>
        <th scope="col">Nombre</th>
        <th scope="col">Telefono</th>
        <th scope="col">Correo</th>
        <th scope="col">IBAM</th>
        <th scope="col">Pais</th>
        <th scope="col">Moneda</th>
        <th scope="col">Importe Mensual</th>
        <th scope="col"></th>
        <th scope="col"></th>
      </tr>
    </thead>
    <tbody>
      <?php if(count($clientes)<=0): ?>
        <tr>
          <td colspan="9">No hay resultados</td>
        </tr>
      <?php else: ?>

        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th hidden scope="row"><?php echo e($cliente->id); ?></th>
        <td><?php echo e($cliente->cif); ?></td>
        <td><?php echo e($cliente->nombre); ?></td>
        <td><?php echo e($cliente->telefono); ?></td>
        <td><?php echo e($cliente->correo); ?></td>
        <td><?php echo e($cliente->cuentacorriente); ?></td>
        <td><?php echo e($cliente->pais); ?></td>
        <td><?php echo e($cliente->moneda); ?></td>
        <td><?php echo e($cliente->importe_mensual); ?></td>
        <td><a href="<?php echo e(route('clientes.edit', $cliente->id)); ?>" class="btn btn-info">Editar</a></td>
        <td><a href="<?php echo e(route('clientes.destroy', $cliente->id)); ?>" class="btn btn-danger">Borrar</a></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    </tbody>
  </table>
  <a href="<?php echo e(route('clientes.create')); ?>" class="btn btn-success">Nuevo Cliente</a><br><br>
  <?php echo e($clientes->links()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\APP\resources\views/clientes/listarCliente.blade.php ENDPATH**/ ?>