

<?php $__env->startSection('cabecera'); ?>

    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<h1 style="text-align: center">Nuevo Cliente</h1>
<form action="/clientes" method="post">
    <div class="form-group">
        <label for="cif">CIF</label>
        <input type="text" class="form-control" name="cif" placeholder="Introduce CIF">
        <?php $__errorArgs = ['cif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="error-message"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <?php echo e(csrf_field()); ?>


      <div class="form-group">
        <label for="nombre">Nombre</label>
        <input type="text" class="form-control" name="nombre"  placeholder="Introduce Nombre">
      </div>
      <div class="form-group">
        <label for="tlf">Telefono</label>
        <input type="text" class="form-control" name="telefono" placeholder="Introduce Telefono" pattern="[0-9]*" maxlength="10">
        <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="error-message"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="form-group">
        <label for="email">Email</label>
        <input type="text" class="form-control" name="correo" placeholder="Introduce email">
      </div>
      <div class="form-group">
        <label for="cuentacorriente">IBAN</label>
        <input type="text" class="form-control" name="cuentacorriente" placeholder="Introduce IBAM">
      </div>
      <div class="form-group">
        <label for="pais">Pais</label>
        <select class="form-control" name="pais"  required>
          <?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($pais->id); ?>"><?php echo e($pais->nombre); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="form-group">
        <label for="moneda">Moneda</label>
        <select class="form-control" name="moneda"  required>
          <?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($pais->iso_moneda); ?>"><?php echo e($pais->iso_moneda); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="form-group">
        <label for="importe_mensual">Importe</label>
        <input type="text" class="form-control" name="importe_mensual" placeholder=".... €">
      </div>

    <input type="submit" value="Crear" name="enviar" class="btn btn-primary">
    <a href="<?php echo e(route('clientes.index')); ?>" class="btn btn-warning">Cancelar</a>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\APP\resources\views/clientes/crearCliente.blade.php ENDPATH**/ ?>