

<?php $__env->startSection('cabecera'); ?>

    


<?php $__env->startSection('contenido'); ?>
<h1 style="text-align: center">Nuevo Cuota</h1>
<form action="/cuotas" method="post">
    <div class="form-group">
        <label for="cif">Concepto</label>
        <input type="text" class="form-control" name="concepto" placeholder="Concepto...">
        <?php $__errorArgs = ['concepto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="error-message"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <?php echo e(csrf_field()); ?>


      <div class="form-group">
        <label for="fecha_emision">Fecha Emision</label>
        <input type="text" class="form-control" name="fecha_emision"  placeholder="00/00/0000" value="<?php echo e($date); ?>" readonly>
      </div>
      <div class="form-group">
        <label for="importe">Importe</label>
        <input type="text" class="form-control" name="importe" placeholder="...€">
        <?php $__errorArgs = ['importe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="error-message"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="form-group">
        <label for="pagado">Pagado</label>
        <input type="text" class="form-control" name="pagado" placeholder="Si o No">
      </div>
      <div class="form-group">
        <label for="fecha_pago">Fecha Pago</label>
        <input type="date" class="form-control" name="fecha_pago" placeholder="00/00/0000">
      </div>
      <div class="form-group">
        <label for="notas">Notas</label>
        <input type="text" class="form-control" name="notas" placeholder="....">
      </div>
      <div class="form-group">
        <label for="cliente_id">Cliente</label>
        <select class="form-control" name="cliente_id"  required>
          <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($cliente->id); ?>"><?php echo e($cliente->cif); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>

    <input type="submit" value="Crear" name="enviar" class="btn btn-primary">
    <a href="<?php echo e(route('cuotas.index')); ?>" class="btn btn-warning">Cancelar</a>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\APP\resources\views/cuotas/crearCuota.blade.php ENDPATH**/ ?>