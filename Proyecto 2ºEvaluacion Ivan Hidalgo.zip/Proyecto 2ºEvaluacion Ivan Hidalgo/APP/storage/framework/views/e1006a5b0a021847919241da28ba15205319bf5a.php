

<?php $__env->startSection('cabecera'); ?>

<?php $__env->startSection('contenido'); ?>

<h1 style="text-align: center">Nosecaen S.L.</h1>
<h4> Lista de Tareas</h4>
<form action="<?php echo e(route('tareas.index')); ?>" method="get">
  <input type="text" class="my-1"name="texto" value="<?php echo e($texto); ?>">
  <input type="submit" class="btn btn-primary my-1" value="Buscar">
</form>

<table class="table table-striped" style="text-align: center">
    <thead>
      <tr>
        <th hidden scope="col">ID</th>
        <th scope="col">Cliente_id</th>
        <th scope="col">User_id</th>
        <th scope="col">Nombre</th>
        <th scope="col">Telefono</th>
        <th scope="col">Descripcion</th>
        <th scope="col">Correo</th>
        <th scope="col">Direccion</th>
        <th scope="col">Poblacion</th>
        <th scope="col">Codigo Postal</th>
        <th scope="col">Provincia</th>
        <th scope="col">Estado</th>
        <th scope="col">Fecha Creacion</th>
        <th scope="col">Operario</th>
        <th scope="col">Fecha Realizacion</th>
        <th scope="col">Anotacion Posterior</th>
        <th scope="col">Anotacion Anterior</th>
        <th scope="col">Fichero</th>
        <th scope="col"></th>
        <th scope="col"></th>
      </tr>
    </thead>
    <tbody>
      <?php if(count($tareas)<=0): ?>
        <tr>
          <td colspan="13">No hay resultados</td>
        </tr>
      <?php else: ?>

        <?php $__currentLoopData = $tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th hidden scope="row"><?php echo e($tarea->id); ?></th>
        <td><?php echo e($tarea->cliente->nombre); ?></td>
        <td><?php echo e($tarea->user->name); ?></td>
        <td><?php echo e($tarea->nombre); ?></td>
        <td><?php echo e($tarea->telefono); ?></td>
        <td><?php echo e($tarea->descripcion); ?></td>
        <td><?php echo e($tarea->correo); ?></td>
        <td><?php echo e($tarea->direccion); ?></td>
        <td><?php echo e($tarea->poblacion); ?></td>
        <td><?php echo e($tarea->codigoPostal); ?></td>
        <td><?php echo e($tarea->provincia); ?></td>
        <td><?php echo e($tarea->estado); ?></td>
        <td><?php echo e($tarea->fechaCreacion); ?></td>
        <td><?php echo e($tarea->operario); ?></td>
        <td><?php echo e($tarea->fechaRealizacion); ?></td>
        <td><?php echo e($tarea->anotacionPos); ?></td>
        <td><?php echo e($tarea->anotacionAnt); ?></td>
        <td><a href="public/images/<?php echo e($tarea->fichero); ?>"><?php echo e($tarea->fichero); ?></a></td>
        <td><a href="<?php echo e(route('tareas.edit', $tarea->id)); ?>" class="btn btn-info">Editar</a></td>
        <td><a href="<?php echo e(route('tareas.destroy', $tarea->id)); ?>" class="btn btn-danger">Borrar</a></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    </tbody>
  </table>
  <a href="<?php echo e(route('tareas.create')); ?>" class="btn btn-success">Nueva Tarea</a><br><br>
  <?php echo e($tareas->links()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\APP\resources\views/tareas/listarTarea.blade.php ENDPATH**/ ?>