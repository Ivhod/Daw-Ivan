

<?php $__env->startSection('cabecera'); ?>

    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<h1 style="text-align: center">Editar Tarea</h1>
<form action="/tareas/<?php echo e($tarea->id); ?>" method="post">
    <?php echo method_field('PUT'); ?>
    <div class="form-group">
      <label for="cliente_id">Cliente</label>
      <select class="form-control" name="cliente_id"  required>
        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($cliente->id); ?>" <?php if($cliente->id == $tarea->cliente_id): ?> selected <?php endif; ?>><?php echo e($cliente->nombre); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      </div>
      <?php echo e(csrf_field()); ?>


      <div class="form-group">
        <label for="user_id">Usuario</label>
        <select class="form-control" name="user_id"  required>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($user->id); ?>" <?php if($user->id == $tarea->user_id): ?> selected <?php endif; ?>><?php echo e($user->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="form-group">
        <label for="nombre">Nombre</label>
        <input type="text" class="form-control" name="nombre" placeholder="Introduce Nombre" value="<?php echo e($tarea->nombre); ?>">
        <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="error-message"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="form-group">
        <label for="telefono">Telefono</label>
        <input type="text" class="form-control" name="telefono" placeholder="Introduce Telefono" value="<?php echo e($tarea->telefono); ?>">
        <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="error-message"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="form-group">
        <label for="descripcion">Descripcion</label>
        <input type="text" class="form-control" name="descripcion" placeholder="Introduce Descripcion" value="<?php echo e($tarea->descripcion); ?>">
        <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="error-message"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="form-group">
        <label for="correo">Correo</label>
        <input type="text" class="form-control" name="correo" placeholder="Introduce Correo" value="<?php echo e($tarea->correo); ?>">
        <?php $__errorArgs = ['correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="error-message"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="form-group">
        <label for="direccion">Direccion</label>
        <input type="text" class="form-control" name="direccion" placeholder="Introduce Direccion" value="<?php echo e($tarea->direccion); ?>">
      </div>
      <div class="form-group">
        <label for="poblacion">Poblacion</label>
        <input type="text" class="form-control" name="poblacion" placeholder="......." value="<?php echo e($tarea->poblacion); ?>">
      </div>
      <div class="form-group">
        <label for="codigoPostal">Codigo Postal</label>
        <input type="text" class="form-control" name="codigoPostal" placeholder="00000" value="<?php echo e($tarea->codigoPostal); ?>">
        <?php $__errorArgs = ['codigoPostal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

          <div class="error-message"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="form-group">
        <label for="provincia">Provincia</label>
        <select class="form-control" name="provincia"  required>
          <?php $__currentLoopData = $provincias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provincia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($provincia->nombre); ?>" <?php if($provincia->nombre == $tarea->provincia): ?> selected <?php endif; ?>><?php echo e($provincia->nombre); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="form-check">
        <input type="radio" id="estado" name="estado" value="realizada">
        Realizada <br> 
        <input type="radio" id="estado" name="estado" value="cancelada">
        Cancelada<br>
        <input type="radio" id="estado" name="estado" value="pendiente">
        Pendiente<br>
      </div>
      <div class="form-group">
        <label for="fechaCreacion">Fecha Creacion</label>
        <input type="text" class="form-control" name="fechaCreacion" placeholder="00/00/0000" value="<?php echo e($tarea->fechaCreacion); ?>" readonly="readonly">
      </div>
      <div class="form-group">
        <label for="operario">Operario</label>
        <select class="form-control" name="operario"  required>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($user->name); ?>" <?php if($user->name == $tarea->operario): ?> selected <?php endif; ?>><?php echo e($user->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="form-group">
        <label for="fechaRealizacion">Fecha Realizacion</label>
        <input type="date" class="form-control" name="fechaRealizacion" placeholder="00/00/0000" value="<?php echo e($tarea->fechaRealizacion); ?>">
        <?php $__errorArgs = ['fechaRealizacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

          <div class="error-message"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="form-group">
        <label for="anotacionPos">Anotacion Posterior</label>
        <input type="text" class="form-control" name="anotacionPos" placeholder="......." value="<?php echo e($tarea->anotacionPos); ?>">
      </div>
    <div class="form-group">
        <label for="anotacionAnt">Anotacion Anterior</label>
        <input type="text" class="form-control" name="anotacionAnt" placeholder="......." value="<?php echo e($tarea->anotacionAnt); ?>" readonly>
      </div>
    <div class="form-group">
        <label for="fichero">Fichero</label>
        <input type="file" class="form-control" name="fichero" placeholder="C/:....." value="<?php echo e($tarea->fichero); ?>">
      </div>

    <input type="submit" value="Editar" name="enviar" class="btn btn-primary">
    <a href="<?php echo e(route('tareas.index')); ?>" class="btn btn-warning">Cancelar</a>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\APP\resources\views/tareas/editarTarea.blade.php ENDPATH**/ ?>