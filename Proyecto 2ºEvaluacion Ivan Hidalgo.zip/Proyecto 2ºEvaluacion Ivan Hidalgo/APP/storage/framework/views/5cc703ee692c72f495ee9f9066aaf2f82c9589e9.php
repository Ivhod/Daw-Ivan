

<?php $__env->startSection('cabecera'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>

<form action="/clientes/<?php echo e($cliente->id); ?>" method="post" style="text-align: center">
    <?php echo e(csrf_field()); ?>

    <?php echo method_field('DELETE'); ?>

    <h4>¿ Seguro que quieres borrar el Cliente <?php echo e($cliente->nombre); ?> ?</h4>
    <a href="<?php echo e(route('clientes.index')); ?>" class="btn btn-warning">Cancelar</a>
    <input type="submit" value="Borrar" class="btn btn-danger">
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\APP\resources\views/clientes/borrarCliente.blade.php ENDPATH**/ ?>