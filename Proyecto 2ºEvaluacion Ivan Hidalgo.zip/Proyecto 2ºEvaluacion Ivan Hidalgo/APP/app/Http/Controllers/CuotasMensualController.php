<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Cuota;
use App\Models\Cliente;

class CuotasMensualController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $date = Carbon::now();
        $date = $date->format('d/m/Y');
        $clientes=Cliente::all();
        return view('cuotas.cuotasMensuales',compact("clientes",'date'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $clienteId = Cliente::pluck('id'); //Trae todos los id de clientes

        $request->validate([
            'concepto' => 'required|max:255',
            'fecha_emision' => 'required|date',
            'importe' => 'required|max:255',
            'notas' => 'required|string|max:255'
        ]);

        foreach ($clienteId as $cliente) {
            $cuota = Cuota::create([
                'concepto' => $request->input('concepto'),
                'fecha_emision' => $request->input('fecha_emision'),
                'importe' => $request->input('importe'),
                'pagada' => $request->input('pagada'),
                'fecha_pago' => $request->input('fecha_pago'),
                'notas' => $request->input('notas'),
                'cliente_id' => $cliente,
            ]);
        }
        return redirect('cuotas');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
