<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Tarea;
use App\Models\User;
use App\Models\Cliente;
use App\Models\Provincia;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class TareasController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        //
        $texto=trim($request->get('texto'));
        $tareas = Tarea::with(['cliente', 'user'])
        ->select('id','cliente_id','user_id','nombre','telefono','descripcion','correo','direccion','poblacion','codigoPostal','provincia','estado','fechaCreacion','operario','fechaRealizacion','anotacionPos','anotacionAnt','fichero')
        ->where('nombre','LIKE','%'.$texto.'%')
        ->orWhere('correo','LIKE','%'.$texto.'%')
        ->orderBy('nombre','ASC')
        ->paginate(5);
        return view('tareas.listarTarea', compact("tareas","texto"));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        
        $date = Carbon::now();
        $date = $date->format('d/m/Y');
        $clientes=Cliente::all();
        $users=User::all();
        $provincias=Provincia::all();
        return view('tareas.crearTarea',compact("clientes","users","provincias",'date'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //Campo Requerido
        $request->validate([
            'nombre' => 'required|max:255',
            'telefono' => 'required|numeric|min:9',
            'descripcion' => 'required|max:255',
            'correo' => 'required|email',
            'fechaRealizacion' => 'date|after:today',
            'codigoPostal' => ['nullable', 'regex:/^[0-9]{5}$/','size:5'],
            
        ]);
        
        


        $tarea=new Tarea();
        $tarea->cliente_id=$request->cliente_id;
        $tarea->user_id=$request->user_id;
        $tarea->nombre=$request->nombre;
        $tarea->telefono=$request->telefono;
        $tarea->descripcion=$request->descripcion;
        $tarea->correo=$request->correo;
        $tarea->direccion=$request->direccion;
        $tarea->poblacion=$request->poblacion;
        $tarea->codigoPostal=$request->codigoPostal;
        $tarea->provincia=$request->provincia;
        $tarea->estado=$request->estado;
        $tarea->fechaCreacion=$request->fechaCreacion;
        $tarea->operario=$request->operario;
        $tarea->fechaRealizacion=$request->fechaRealizacion;
        $tarea->anotacionPos=$request->anotacionPos;
        $tarea->anotacionAnt=$request->anotacionAnt;
        
        $entrada=$request->all();
        if ($archivo=$request->file('fichero')) {
            $nombre=$archivo->getClientOriginalName();
            $archivo->move('public/images',$nombre);
            $entrada['fichero']=$nombre;
        }
        Tarea::create($entrada);

        //$tarea->save();
        return redirect('tareas');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $tarea=Tarea::findOrFail($id);
        return view('tareas.borrarTarea', compact('tarea'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $clientes=Cliente::all();
        $users=User::all();
        $provincias=Provincia::all();
        $tarea=Tarea::findOrFail($id);
        return view('tareas.editarTarea', compact('tarea','clientes','users','provincias'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $request->validate([
            'nombre' => 'required|max:255',
            'telefono' => 'required|numeric|min:9',
            'descripcion' => 'required|max:255',
            'correo' => 'required|email',
            'fechaRealizacion' => 'date|after:today',
            'codigoPostal' => ['nullable', 'regex:/^[0-9]{5}$/','size:5']
        ]);
        
        $tarea=Tarea::findOrFail($id);
        $tarea->update($request->all());

        return redirect('tareas');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $tarea=Tarea::findOrFail($id);
        $tarea->delete();
        return redirect('tareas');
    }

}
