<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cliente;
use App\Models\Pais;
use Illuminate\Support\Facades\DB;

class ClientesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     * Esto lista las tareas de clientes
     */
    public function index(Request $request)
    {
        //
        $texto=trim($request->get('texto'));
        $clientes=DB::table('clientes')
        ->select('id','cif','nombre','telefono','correo','cuentacorriente','pais','moneda','importe_mensual')
        ->where('nombre','LIKE','%'.$texto.'%')
        ->orWhere('cif','LIKE','%'.$texto.'%')
        ->orderBy('nombre','ASC')
        ->paginate(5);
        return view('clientes.listarCliente', compact("clientes","texto"));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     * Manda a la vista de crear cliente
     */
    public function create()
    {
        //
        $paises=Pais::all();
        return view('clientes.crearCliente' ,compact("paises"));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     * Guarda los datos del formulario
     */
    public function store(Request $request)
    {
        //
        //return view('clientes.listarCliente');
        $request->validate([
            'cif' => 'required|max:255',
            'telefono' => 'required|numeric|min:9',
        ]);

        $cliente=new Cliente();
        $cliente->cif=$request->cif;
        $cliente->nombre=$request->nombre;
        $cliente->telefono=$request->telefono;
        $cliente->correo=$request->correo;
        $cliente->cuentacorriente=$request->cuentacorriente;
        $cliente->pais=$request->pais;
        $cliente->moneda=$request->moneda;
        $cliente->importe_mensual=$request->importe_mensual;

        $cliente->save();
        return redirect('clientes');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     * Manda a la vista de Borrar cliente
     */
    public function show($id)
    {
        //
        $cliente=Cliente::findOrFail($id);
        return view('clientes.borrarCliente', compact('cliente'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     * Manda a la vista de editar cliente
     */
    public function edit($id)
    {
        //
        $paises=Pais::all();
        $cliente=Cliente::findOrFail($id);
        return view('clientes.editarCliente', compact('cliente','paises'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     * Actualiza los datos del formulario
     */
    public function update(Request $request, $id)
    {
        //
        $request->validate([
            'cif' => 'required|max:255',
            'telefono' => 'required|numeric|min:9',
        ]);
        $cliente=Cliente::findOrFail($id);
        $cliente->update($request->all());

        return redirect('clientes');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     * Eliminar los datos del listar
     */
    public function destroy($id)
    {
        //
        $cliente=Cliente::findOrFail($id);
        $cliente->delete();
        return redirect('clientes');
        
    }
}
