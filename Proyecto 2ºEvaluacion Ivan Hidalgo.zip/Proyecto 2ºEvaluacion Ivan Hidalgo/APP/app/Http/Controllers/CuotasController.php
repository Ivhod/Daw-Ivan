<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cuota;
use App\Models\Cliente;
// use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Dompdf\Dompdf;
use Illuminate\Support\Facades\Mail;
use App\Mail\FacturaGenerada;

class CuotasController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    // public function index(Request $request)
    // {
    //     //
    //     $texto=trim($request->get('texto'));
    //     $cuotas=DB::table('cuotas')
    //     ->select('id','concepto','fecha_emision','importe','pagado','fecha_pago','notas','cliente_id')
    //     ->where('cliente_id','LIKE','%'.$texto.'%')
    //     ->orWhere('concepto','LIKE','%'.$texto.'%')
    //     ->orderBy('fecha_emision','ASC')
    //     ->paginate(5);
    //     return view('cuotas.listarCuota', compact("cuotas",'texto'));

    // }

    public function index(Request $request)
    {
        $texto = trim($request->get('texto'));
        $cuotas = Cuota::with('cliente')
            ->where('cliente_id', 'LIKE', '%' . $texto . '%')
            ->orWhere('concepto', 'LIKE', '%' . $texto . '%')
            ->orderBy('fecha_emision', 'ASC')
            ->paginate(5);
        return view('cuotas.listarCuota', compact('cuotas', 'texto'));
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $date = Carbon::now();
        $date = $date->format('d/m/Y');
        $clientes = Cliente::all();
        return view('cuotas.crearCuota', compact("clientes", 'date'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'concepto' => 'required|max:255',
            'importe' => 'required|max:255',
        ]);
    
        $cuota = new Cuota();
        $cuota->concepto = $request->concepto;
        $cuota->fecha_emision = $request->fecha_emision;
        $cuota->importe = $request->importe;
        $cuota->pagado = $request->pagado;
        $cuota->fecha_pago = $request->fecha_pago;
        $cuota->notas = $request->notas;
        $cuota->cliente_id = $request->cliente_id;
        $cuota->save();
    
        $cliente = Cliente::find($request->cliente_id);
        $correo = $cliente->correo;
    
        $fecha_emision = $cuota->fecha_emision;
        $concepto = $cuota->concepto;
        $importe = $cuota->importe;
        $fecha_pago = $cuota->fecha_pago;
        
        $html = view('cuotas.facturaDescarga', compact('cuota', 'fecha_emision', 'concepto', 'importe', 'fecha_pago'))->render();
        $email = new FacturaGenerada($html);
        Mail::to($correo)->send($email);
    
        return redirect('cuotas');
    }
    

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $cuota = Cuota::findOrFail($id);
        return view('cuotas.borrarCuota', compact('cuota'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //

        $clientes = Cliente::all();
        $cuota = Cuota::findOrFail($id);
        return view('cuotas.editarCuota', compact('cuota', 'clientes'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $request->validate([
            'concepto' => 'required|max:255',
            'importe' => 'required|max:255',
        ]);
        $cuota = Cuota::findOrFail($id);
        $cuota->update($request->all());

        return redirect('cuotas');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $cuota = Cuota::findOrFail($id);
        $cuota->delete();
        return redirect('cuotas');
    }

    public function descargarFactura($id)
    {
        // Obtener la cuota
        $cuota = Cuota::find($id);
        $fecha_emision = $cuota->fecha_emision;
        $concepto = $cuota->concepto;
        $importe = $cuota->importe;
        $fecha_pago = $cuota->fecha_pago;
        $html = view('cuotas.facturaDescarga', compact('cuota', 'fecha_emision', 'concepto', 'importe', 'fecha_pago'))->render();

        // cargar vista en HTML
        $pdf = new Dompdf();
        $pdf->loadHtml($html);

        // Renderizar el PDF
        $pdf->render();

        // Descargar el PDF
        return $pdf->stream('factura_' . $cuota->cliente->nombre  . '.pdf');
    }

    public function mostrarFactura($id)
    { //Monstrar Factura

        $cuota = Cuota::findOrFail($id);
        $fecha_emision = $cuota->fecha_emision;
        $concepto = $cuota->concepto;
        $importe = $cuota->importe;
        $fecha_pago = $cuota->fecha_pago;

        return view('cuotas.factura', compact('cuota', 'fecha_emision', 'concepto', 'importe', 'fecha_pago'));
    }
}
