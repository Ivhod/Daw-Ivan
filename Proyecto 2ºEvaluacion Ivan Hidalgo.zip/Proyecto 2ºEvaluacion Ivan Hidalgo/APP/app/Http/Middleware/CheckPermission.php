<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CheckPermission
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        $user = Auth::user();
        if ($user->rol=='admin') {
            return $next($request);
        }
        // Si el usuario no tiene el rol de administrador, solo mostramos los campos de fecha de emisión y concepto.
        $request->request->remove('importe');
        $request->request->remove('pagado');
        $request->request->remove('fecha_pago');
        $request->request->remove('notas');
        $request->request->remove('cliente');
        return $next($request);
    }
}
