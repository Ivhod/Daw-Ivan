<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class RoleMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    //SI EL USUARIO AL QUE ENTRA NO ES ADMINISTRADOR
    public function handle(Request $request, Closure $next) 
    {
        if(!auth()->check() || Auth()->user()->rol !='admin'){
            return redirect('tareasOperario');
        }
        return $next($request);
    }
}
