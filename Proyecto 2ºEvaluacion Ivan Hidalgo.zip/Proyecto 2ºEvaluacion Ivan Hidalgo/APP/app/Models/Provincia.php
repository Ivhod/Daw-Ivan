<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Provincia extends Model
{
    use HasFactory;

    //El modelo de la tabla de provincias
    ////////////////////////////////
    
    protected $table = 'provincias';
    protected $primaryKey = 'cod';
    protected $fillable =[
        'nombre',
        'comunidad_id'
    ];
}
