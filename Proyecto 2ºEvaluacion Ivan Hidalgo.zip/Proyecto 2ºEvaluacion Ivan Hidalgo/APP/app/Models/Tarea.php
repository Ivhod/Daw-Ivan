<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tarea extends Model
{
    use HasFactory;
    //Modelo de datos de la tabla tareas
    ////////////////////////////////

    protected $table = 'tareas';
    protected $primaryKey = 'id';
    protected $fillable =[
        'cliente_id',
        'user_id',
        'nombre',
        'telefono',
        'descripcion',
        'correo',
        'direccion',
        'poblacion',
        'codigoPostal',
        'provincia',
        'estado',
        'fechaCreacion',
        'operario',
        'fechaRealizacion',
        'anotacionPos',
        'anotacionAnt',
        'fichero'
    ];
    //Relaciones a las diferentes tabla en este caso a la tabla clientes y usuarios
    ////////////////////////////////
    
    public function cliente(){
        return $this->belongsTo(Cliente::class);
    }
    public function user(){
        return $this->belongsTo(User::class);
    }
}
