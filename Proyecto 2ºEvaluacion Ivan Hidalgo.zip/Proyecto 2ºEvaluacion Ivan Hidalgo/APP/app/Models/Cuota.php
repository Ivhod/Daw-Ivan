<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Cliente;

class Cuota extends Model
{
    use HasFactory;
    protected $table = 'cuotas';
    //El modelo de la tabla de cuotas
    ////////////////////////////////
    
    protected $primaryKey = 'id';
    protected $fillable =[
        'concepto',
        'fecha_emision',
        'importe',
        'pagado',
        'fecha_pago',
        'notas',
        'cliente_id'
    ];

    //Las relaciones de la tabla hacia cliente
    ////////////////////////////////
    
    public function cliente(){
        return $this->belongsTo(Cliente::class);
    }
}
