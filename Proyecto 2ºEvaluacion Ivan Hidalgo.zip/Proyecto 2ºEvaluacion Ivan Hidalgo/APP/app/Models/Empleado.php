<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Empleado extends Model
{
    //use HasFactory;
    //El modelo de la tabla de empleados
    ////////////////////////////////
    
    protected $table = 'empleados';
    protected $primaryKey = 'id';
    protected $fillable =[
        'dni',
        'nombre',
        'correo',
        'telefono',
        'direccion',
        'fechaAlta',
        'tipo'
    ];
}
