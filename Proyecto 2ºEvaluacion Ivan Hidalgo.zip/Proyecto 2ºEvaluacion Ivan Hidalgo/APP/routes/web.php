<?php


use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ClientesController;
use App\Http\Controllers\CuotasController;
use App\Http\Controllers\CuotasMensualController;
use App\Http\Controllers\UsersController;
use App\Http\Controllers\TareasController;
use App\Http\Controllers\FacturasController;
use App\Http\Controllers\TareasOperarioController;
use Illuminate\Support\Facades\Auth;
use Laravel\Socialite\Facades\Socialite;
use App\Models\User;
use Illuminate\Support\Facades\Mail;
use App\Mail\ContactanosMailable;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


//El inicio del proyecto donde estaria el login
Route::get('/', function () {
    return view('auth/login');
});

//Las diferentes rutas hacia los controladores y vistas y metodos del programa
////////////////////////////////
//Route::resource('/clientes', ClientesController::class);
Route::middleware(["role", "auth"])->resource('/clientes', ClientesController::class);

//Route::resource('/cuotas', CuotasController::class);
Route::middleware(['role',"auth"])->resource('/cuotas', CuotasController::class);

Route::middleware(['role',"auth"])->resource('/cuotasMensuales', CuotasMensualController::class);

//Route::resource('/users', UsersController::class);
Route::middleware(['role',"auth"])->resource('/users', UsersController::class);

//Route::resource('/tareas', TareasController::class);
Route::middleware(['role',"auth"])->resource('/tareas', TareasController::class);

Route::middleware(["auth","roleOperario"])->resource('/tareasOperario', TareasOperarioController::class);

Route::get('/cuotas/{id}/mostrarFactura', [CuotasController::class, 'mostrarFactura'])->name('cuotas.mostrarFactura')->middleware(['auth', 'role']);

Route::get('/cuotas/{cuota}/descargarFactura', [CuotasController::class, 'descargarFactura'])->name('cuotas.descargarFactura');





Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

//Login con google
////////////////////////////////
Route::get('/login-google', function () {
    return Socialite::driver('google')->redirect();
});
 
Route::get('/google-callback', function () {
    $user = Socialite::driver('google')->user();
    
    $userExists= User::where('external_id', $user->id)->where('external_auth','google')->first();

    if($userExists){
        Auth::login($userExists);
    }else {
        $userNew =User::create([
            'name'=>$user->name,
            'email'=>$user->email,
            'avatar'=>$user->avatar,
            'external_id'=>$user->id,
            'external_auth'=> 'google',
        ]);

        Auth::login($userNew);
    }

 return redirect('/clientes');
    // $user->token
});


//////Login Github
////////////////////////////////
Route::get('/login-github', function () {
    return Socialite::driver('github')->redirect();
});
 
Route::get('/github-callback', function () {
    $user = Socialite::driver('github')->user();
    
    $userExists= User::where('external_id', $user->id)->where('external_auth','github')->first();

    if($userExists){
        Auth::login($userExists);
    }else {
        $userNew =User::create([
            'name'=>$user->nickname,
            'email'=>$user->email,
            'avatar'=>$user->avatar,
            'external_id'=>$user->id,
            'external_auth'=> 'github',
        ]);

        Auth::login($userNew);
    }

 return redirect('/clientes');
    // $user->token
});


