<?php

namespace Tests\Feature;

// use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ExampleTest extends TestCase
{
    /**
     * A basic test example.
     *
     * @return void
     * PRUEBAS UNITARIAS DE LAS RUTAS
     */
    public function text_example()
    {
        $response = $this->get('/');

        $response->assertStatus(200);

        $response = $this->get('/logout');
        $response->assertStatus(302);

        $response = $this->get('/home');
        $response->assertStatus(302);

        $response = $this->get('/clientes');
        $response->assertStatus(302);

        $response = $this->get('/users');
        $response->assertStatus(302);

        $response = $this->get('/tareas');
        $response->assertStatus(302);

        $response = $this->get('/tareas/create');
        $response->assertStatus(302);

        $response = $this->get('/cuotas');
        $response->assertStatus(302);

        $response = $this->get('/cuotas/create');
        $response->assertStatus(302);

        $response = $this->get('/cuotasMensuales');
        $response->assertStatus(302);

        $response = $this->get('/tareasOperarios');
        $response->assertStatus(302);

        $response = $this->get('/cuotasMensuales');
        $response->assertStatus(302);
        
        $response = $this->get('/cuotasMensuales/create');
        $response->assertStatus(302);
    }
}
