@extends('layouts.plantilla')

@section('cabecera')

    
@endsection

@section('contenido')
<h1 style="text-align: center">Editar Cuota</h1>
<form action="/cuotas/{{$cuota->id}}" method="post">
    @method('PUT')
    <div class="form-group">
        <label for="concepto">Concepto</label>
        <input type="text" class="form-control" name="concepto" placeholder="Concepto..." value="{{$cuota->concepto}}">
        @error('concepto')
          <div class="error-message">{{ $message }}</div>
        @enderror
      </div>
      {{csrf_field()}}

      <div class="form-group">
        <label for="fecha_emision">Fecha Emision</label>
        <input type="text" class="form-control" name="fecha_emision"  placeholder="00/00/0000" value="{{$cuota->fecha_emision}}" readonly>
      </div>
      <div class="form-group">
        <label for="importe">Importe</label>
        <input type="text" class="form-control" name="importe" placeholder="...€" value="{{$cuota->importe}}">
        @error('importe')
          <div class="error-message">{{ $message }}</div>
        @enderror
      </div>
      <div class="form-group">
        <label for="pagado">Pagado</label>
        <input type="text" class="form-control" name="pagado" placeholder="Si o No" value="{{$cuota->pagado}}">
      </div>
      <div class="form-group">
        <label for="fecha_pago">Fecha de Pago</label>
        <input type="date" class="form-control" name="fecha_pago" placeholder="00/00/0000" value="{{$cuota->fecha_pago}}">
      </div>
      <div class="form-group">
        <label for="notas">Notas</label>
        <input type="text" class="form-control" name="notas" placeholder="......" value="{{$cuota->notas}}">
      </div>
      <div class="form-group">
        <label for="cliente_id">Cliente</label>
        <select class="form-control" name="cliente_id"  required>
          @foreach ($clientes as $cliente)
              <option value="{{$cliente->id}}" @if($cliente->id == $cuota->cliente_id) selected @endif>{{$cliente->cif}}</option>
          @endforeach
        </select>
      </div>

    <input type="submit" value="Editar" name="enviar" class="btn btn-primary">
    <a href="{{ route('cuotas.index') }}" class="btn btn-warning">Cancelar</a>
</form>

@endsection