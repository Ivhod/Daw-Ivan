@extends('layouts.plantilla')

@section('cabecera')

@endsection

@section('contenido')

<div style="text-align: center">
    <h1>Factura</h1>
    <p>Fecha: {{ $fecha_emision }}</p>
    <table border="1px">
        <thead>
            <tr>
                <th>Concepto</th>
                <th>Importe</th>
                <th>Fecha de Pago</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>{{$concepto}}</td>
                <td>{{$importe}}</td>
                <td>{{$fecha_pago}}</td>
            </tr>
        </tbody>
    </table>
    <a href="{{ route('cuotas.index') }}" class="btn btn-warning">Volver</a>
</div>
@endsection

