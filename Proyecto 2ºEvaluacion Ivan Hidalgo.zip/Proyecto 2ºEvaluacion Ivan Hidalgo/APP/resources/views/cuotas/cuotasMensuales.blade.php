@extends('layouts.plantilla')

@section('cabecera')

    


@section('contenido')
<h1 style="text-align: center">Nuevo Cuota</h1>
<form action="/cuotasMensuales" method="post">
    <div class="form-group">
        <label for="cif">Concepto</label>
        <input type="text" class="form-control" name="concepto" placeholder="Concepto...">
        @error('concepto')
          <div class="error-message">{{ $message }}</div>
        @enderror
      </div>
      {{csrf_field()}}

      <div class="form-group">
        <label for="fecha_emision">Fecha Emision</label>
        <input type="text" class="form-control" name="fecha_emision"  placeholder="00/00/0000" value="{{$date}}" readonly>
      </div>
      <div class="form-group">
        <label for="importe">Importe</label>
        <input type="text" class="form-control" name="importe" placeholder="...€">
        @error('importe')
          <div class="error-message">{{ $message }}</div>
        @enderror
      </div>
      <div class="form-group">
        <label for="pagado">Pagado</label>
        <input type="text" class="form-control" name="pagado" placeholder="Si o No">
      </div>
      <div class="form-group">
        <label for="fecha_pago">Fecha Pago</label>
        <input type="date" class="form-control" name="fecha_pago" placeholder="00/00/0000">
      </div>
      <div class="form-group">
        <label for="notas">Notas</label>
        <input type="text" class="form-control" name="notas" placeholder="....">
      </div>

    <input type="submit" value="Crear" name="enviar" class="btn btn-primary">
    <a href="{{ route('cuotas.index') }}" class="btn btn-warning">Cancelar</a>
</form>

@endsection