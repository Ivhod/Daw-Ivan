@extends('layouts.plantilla')

@section('cabecera')

@endsection

@section('contenido')

<form action="/cuotas/{{$cuota->id}}" method="post" style="text-align: center">
    {{csrf_field()}}
    @method('DELETE')

    <h4>¿ Seguro que quieres borrar la Cuota del Cliente {{$cuota->cliente_id}} ?</h4>
    <a href="{{ route('cuotas.index') }}" class="btn btn-warning">Cancelar</a>
    <input type="submit" value="Borrar" class="btn btn-danger">
</form>
@endsection