@extends('layouts.plantilla')

@section('cabecera')

@section('contenido')

<h1 style="text-align: center">Nosecaen S.L.</h1>
<h4> Lista de Cuotas</h4>

<form action="{{route('cuotas.index')}}" method="get">
    <input type="text" class="my-1" name="texto" value="{{$texto}}">
    <input type="submit" class="btn btn-primary my-1" value="Buscar">
  </form>

<table class="table table-striped" style="text-align: center">
    <thead>
      <tr>
        <th hidden scope="col">ID</th>
        <th scope="col">Concepto</th>
        <th scope="col">Fecha Emision</th>
        <th scope="col">Importe</th>
        <th scope="col">Pagado</th>
        <th scope="col">Fecha de Pago</th>
        <th scope="col">Notas</th>
        <th scope="col">Cliente</th>
        <th scope="col"></th>
        <th scope="col"></th>
        <th scope="col"></th>
      </tr>
    </thead>
    <tbody>
        @if(count($cuotas)<=0)
        <tr>
          <td colspan="9">No hay resultados</td>
        </tr>
      @else

        @foreach ($cuotas as $cuota)
      <tr>
        <th hidden scope="row">{{$cuota->id}}</th>
        <td>{{$cuota->concepto}}</td>
        <td>{{$cuota->fecha_emision}}</td>
        <td>{{$cuota->importe}} €</td>
        <td>{{$cuota->pagado}}</td>
        <td>{{$cuota->fecha_pago}}</td>
        <td>{{$cuota->notas}}</td>
        <td>{{$cuota->cliente->nombre}}</td>
        <td>
          <a href="{{ route('cuotas.mostrarFactura', $cuota->id)}}" class="btn btn-primary"><i class="fa fa-eye" aria-hidden="true"></i></a>
          <a href="{{ route('cuotas.edit', $cuota->id)}}" class="btn btn-info">Editar</a>
          <a href="{{ route('cuotas.descargarFactura', $cuota->id)}}" class="btn btn-dark"><i class="fa fa-download" aria-hidden="true"></i></a>
        </td>
        <td>
          
          <a href="{{ route('cuotas.destroy', $cuota->id)}}" class="btn btn-danger">Borrar</a>
        </td>
        <td></td>
      </tr>
      @endforeach
      @endif
    </tbody>
  </table>
  <a href="{{ route('cuotas.create') }}" class="btn btn-success">Nueva Cuota</a>
  <a href="{{ route('cuotasMensuales.create') }}" class="btn btn-info">Cuota Mensual</a><br><br>
  <br><br>
  
  {{ $cuotas->links() }}

  @endsection