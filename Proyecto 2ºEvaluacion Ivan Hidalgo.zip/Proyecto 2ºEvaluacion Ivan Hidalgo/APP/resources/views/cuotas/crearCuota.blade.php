@extends('layouts.plantilla')

@section('cabecera')

    


@section('contenido')
<h1 style="text-align: center">Nuevo Cuota</h1>
<form action="/cuotas" method="post">
    <div class="form-group">
        <label for="cif">Concepto</label>
        <input type="text" class="form-control" name="concepto" placeholder="Concepto...">
        @error('concepto')
          <div class="error-message">{{ $message }}</div>
        @enderror
      </div>
      {{csrf_field()}}

      <div class="form-group">
        <label for="fecha_emision">Fecha Emision</label>
        <input type="text" class="form-control" name="fecha_emision"  placeholder="00/00/0000" value="{{$date}}" readonly>
      </div>
      <div class="form-group">
        <label for="importe">Importe</label>
        <input type="text" class="form-control" name="importe" placeholder="...€">
        @error('importe')
          <div class="error-message">{{ $message }}</div>
        @enderror
      </div>
      <div class="form-group">
        <label for="pagado">Pagado</label>
        <input type="text" class="form-control" name="pagado" placeholder="Si o No">
      </div>
      <div class="form-group">
        <label for="fecha_pago">Fecha Pago</label>
        <input type="date" class="form-control" name="fecha_pago" placeholder="00/00/0000">
      </div>
      <div class="form-group">
        <label for="notas">Notas</label>
        <input type="text" class="form-control" name="notas" placeholder="....">
      </div>
      <div class="form-group">
        <label for="cliente_id">Cliente</label>
        <select class="form-control" name="cliente_id"  required>
          @foreach ($clientes as $cliente)
              <option value="{{$cliente->id}}">{{$cliente->cif}}</option>
          @endforeach
        </select>
      </div>

    <input type="submit" value="Crear" name="enviar" class="btn btn-primary">
    <a href="{{ route('cuotas.index') }}" class="btn btn-warning">Cancelar</a>
</form>

@endsection