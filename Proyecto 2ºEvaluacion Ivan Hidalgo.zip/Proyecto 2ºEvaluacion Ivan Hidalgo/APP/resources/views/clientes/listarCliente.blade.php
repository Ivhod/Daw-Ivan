@extends('layouts.plantilla')

@section('cabecera')

@section('contenido')

<h1 style="text-align: center">Nosecaen S.L.</h1>

<h4> Lista de Clientes</h4>
<form action="{{route('clientes.index')}}" method="get">
  <input type="text" class="my-1"name="texto" value="{{$texto}}">
  <input type="submit" class="btn btn-primary my-1" value="Buscar">
</form>

<table class="table table-striped" style="text-align: center">
    <thead>
      <tr>
        <th hidden scope="col">ID</th>
        <th scope="col">CIF</th>
        <th scope="col">Nombre</th>
        <th scope="col">Telefono</th>
        <th scope="col">Correo</th>
        <th scope="col">IBAM</th>
        <th scope="col">Pais</th>
        <th scope="col">Moneda</th>
        <th scope="col">Importe Mensual</th>
        <th scope="col"></th>
        <th scope="col"></th>
      </tr>
    </thead>
    <tbody>
      @if(count($clientes)<=0)
        <tr>
          <td colspan="9">No hay resultados</td>
        </tr>
      @else

        @foreach ($clientes as $cliente)
      <tr>
        <th hidden scope="row">{{$cliente->id}}</th>
        <td>{{$cliente->cif}}</td>
        <td>{{$cliente->nombre}}</td>
        <td>{{$cliente->telefono}}</td>
        <td>{{$cliente->correo}}</td>
        <td>{{$cliente->cuentacorriente}}</td>
        <td>{{$cliente->pais}}</td>
        <td>{{$cliente->moneda}}</td>
        <td>{{$cliente->importe_mensual}}</td>
        <td><a href="{{ route('clientes.edit', $cliente->id)}}" class="btn btn-info">Editar</a></td>
        <td><a href="{{ route('clientes.destroy', $cliente->id)}}" class="btn btn-danger">Borrar</a></td>
      </tr>
      @endforeach
      @endif
    </tbody>
  </table>
  <a href="{{ route('clientes.create') }}" class="btn btn-success">Nuevo Cliente</a><br><br>
  {{ $clientes->links() }}

@endsection
