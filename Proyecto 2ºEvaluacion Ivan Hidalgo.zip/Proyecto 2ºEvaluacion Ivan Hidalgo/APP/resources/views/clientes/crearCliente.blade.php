@extends('layouts.plantilla')

@section('cabecera')

    
@endsection

@section('contenido')
<h1 style="text-align: center">Nuevo Cliente</h1>
<form action="/clientes" method="post">
    <div class="form-group">
        <label for="cif">CIF</label>
        <input type="text" class="form-control" name="cif" placeholder="Introduce CIF">
        @error('cif')
          <div class="error-message">{{ $message }}</div>
        @enderror
      </div>
      {{csrf_field()}}

      <div class="form-group">
        <label for="nombre">Nombre</label>
        <input type="text" class="form-control" name="nombre"  placeholder="Introduce Nombre">
      </div>
      <div class="form-group">
        <label for="tlf">Telefono</label>
        <input type="text" class="form-control" name="telefono" placeholder="Introduce Telefono" pattern="[0-9]*" maxlength="10">
        @error('telefono')
          <div class="error-message">{{ $message }}</div>
        @enderror
      </div>
      <div class="form-group">
        <label for="email">Email</label>
        <input type="text" class="form-control" name="correo" placeholder="Introduce email">
      </div>
      <div class="form-group">
        <label for="cuentacorriente">IBAN</label>
        <input type="text" class="form-control" name="cuentacorriente" placeholder="Introduce IBAM">
      </div>
      <div class="form-group">
        <label for="pais">Pais</label>
        <select class="form-control" name="pais"  required>
          @foreach ($paises as $pais)
              <option value="{{$pais->id}}">{{$pais->nombre}}</option>
          @endforeach
        </select>
      </div>
      <div class="form-group">
        <label for="moneda">Moneda</label>
        <select class="form-control" name="moneda"  required>
          @foreach ($paises as $pais)
              <option value="{{$pais->iso_moneda}}">{{$pais->iso_moneda}}</option>
          @endforeach
        </select>
      </div>
      <div class="form-group">
        <label for="importe_mensual">Importe</label>
        <input type="text" class="form-control" name="importe_mensual" placeholder=".... €">
      </div>

    <input type="submit" value="Crear" name="enviar" class="btn btn-primary">
    <a href="{{ route('clientes.index') }}" class="btn btn-warning">Cancelar</a>
</form>

@endsection