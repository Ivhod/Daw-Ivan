@extends('layouts.plantilla')

@section('cabecera')

    
@endsection

@section('contenido')
<h1 style="text-align: center">Editar Cliente</h1>
<form action="/clientes/{{$cliente->id}}" method="post">
    @method('PUT')
    <div class="form-group">
        <label for="cif">CIF</label>
        <input type="text" class="form-control" name="cif" placeholder="Introduce CIF" value="{{$cliente->cif}}">
        @error('cif')
          <div class="error-message">{{ $message }}</div>
        @enderror
      </div>
      {{csrf_field()}}

      <div class="form-group">
        <label for="nombre">Nombre</label>
        <input type="text" class="form-control" name="nombre"  placeholder="Introduce Nombre" value="{{$cliente->nombre}}">
      </div>
      <div class="form-group">
        <label for="tlf">Telefono</label>
        <input type="text" class="form-control" name="telefono" placeholder="Introduce Telefono" value="{{$cliente->telefono}}" pattern="[0-9]*" maxlength="10">
        @error('telefono')
          <div class="error-message">{{ $message }}</div>
        @enderror
      </div>
      <div class="form-group">
        <label for="email">Email</label>
        <input type="text" class="form-control" name="correo" placeholder="Introduce email" value="{{$cliente->correo}}">
      </div>
      <div class="form-group">
        <label for="cuentacorriente">IBAN</label>
        <input type="text" class="form-control" name="cuentacorriente" placeholder="Introduce IBAM" value="{{$cliente->cuentacorriente}}">
      </div>
      <div class="form-group">
        <label for="pais">Pais</label>
        <select class="form-control" name="pais"  required>
          @foreach ($paises as $pais)
              <option value="{{$pais->id}}" @if($pais->id == $cliente->pais) selected @endif>{{$pais->nombre}}</option>
          @endforeach
        </select>
      </div>
      <div class="form-group">
        <label for="moneda">Moneda</label>
        <select value="{{$cliente->moneda}}" class="form-control" name="moneda"  required>
          @foreach ($paises as $pais)
              <option value="{{$pais->iso_moneda}}" @if($pais->iso_moneda == $cliente->moneda) selected @endif>{{$pais->iso_moneda}}</option>
          @endforeach
        </select>
      </div>
      <div class="form-group">
        <label for="importe_mensual">Importe</label>
        <input type="text" class="form-control" name="importe_mensual" placeholder="Introduce Importe" value="{{$cliente->importe_mensual}}">
      </div>

    <input type="submit" value="Editar" name="enviar" class="btn btn-primary">
    <a href="{{ route('clientes.index') }}" class="btn btn-warning">Cancelar</a>
</form>

@endsection