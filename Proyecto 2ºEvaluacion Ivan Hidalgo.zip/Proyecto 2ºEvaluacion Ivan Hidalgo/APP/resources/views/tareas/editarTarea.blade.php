@extends('layouts.plantilla')

@section('cabecera')

    
@endsection

@section('contenido')
<h1 style="text-align: center">Editar Tarea</h1>
<form action="/tareas/{{$tarea->id}}" method="post">
    @method('PUT')
    <div class="form-group">
      <label for="cliente_id">Cliente</label>
      <select class="form-control" name="cliente_id"  required>
        @foreach ($clientes as $cliente)
            <option value="{{$cliente->id}}" @if($cliente->id == $tarea->cliente_id) selected @endif>{{$cliente->nombre}}</option>
        @endforeach
      </select>
      </div>
      {{csrf_field()}}

      <div class="form-group">
        <label for="user_id">Usuario</label>
        <select class="form-control" name="user_id"  required>
          @foreach ($users as $user)
              <option value="{{$user->id}}" @if($user->id == $tarea->user_id) selected @endif>{{$user->name}}</option>
          @endforeach
        </select>
      </div>
      <div class="form-group">
        <label for="nombre">Nombre</label>
        <input type="text" class="form-control" name="nombre" placeholder="Introduce Nombre" value="{{$tarea->nombre}}">
        @error('nombre')
          <div class="error-message">{{ $message }}</div>
        @enderror
      </div>
      <div class="form-group">
        <label for="telefono">Telefono</label>
        <input type="text" class="form-control" name="telefono" placeholder="Introduce Telefono" value="{{$tarea->telefono}}">
        @error('telefono')
          <div class="error-message">{{ $message }}</div>
        @enderror
      </div>
      <div class="form-group">
        <label for="descripcion">Descripcion</label>
        <input type="text" class="form-control" name="descripcion" placeholder="Introduce Descripcion" value="{{$tarea->descripcion}}">
        @error('descripcion')
          <div class="error-message">{{ $message }}</div>
        @enderror
      </div>
      <div class="form-group">
        <label for="correo">Correo</label>
        <input type="text" class="form-control" name="correo" placeholder="Introduce Correo" value="{{$tarea->correo}}">
        @error('correo')
          <div class="error-message">{{ $message }}</div>
        @enderror
      </div>
      <div class="form-group">
        <label for="direccion">Direccion</label>
        <input type="text" class="form-control" name="direccion" placeholder="Introduce Direccion" value="{{$tarea->direccion}}">
      </div>
      <div class="form-group">
        <label for="poblacion">Poblacion</label>
        <input type="text" class="form-control" name="poblacion" placeholder="......." value="{{$tarea->poblacion}}">
      </div>
      <div class="form-group">
        <label for="codigoPostal">Codigo Postal</label>
        <input type="text" class="form-control" name="codigoPostal" placeholder="00000" value="{{$tarea->codigoPostal}}">
        @error('codigoPostal')

          <div class="error-message">{{ $message }}</div>
        @enderror
      </div>
      <div class="form-group">
        <label for="provincia">Provincia</label>
        <select class="form-control" name="provincia"  required>
          @foreach ($provincias as $provincia)
              <option value="{{$provincia->nombre}}" @if($provincia->nombre == $tarea->provincia) selected @endif>{{$provincia->nombre}}</option>
          @endforeach
        </select>
      </div>
      <div class="form-check">
        <input type="radio" id="estado" name="estado" value="realizada">
        Realizada <br> 
        <input type="radio" id="estado" name="estado" value="cancelada">
        Cancelada<br>
        <input type="radio" id="estado" name="estado" value="pendiente">
        Pendiente<br>
      </div>
      <div class="form-group">
        <label for="fechaCreacion">Fecha Creacion</label>
        <input type="text" class="form-control" name="fechaCreacion" placeholder="00/00/0000" value="{{$tarea->fechaCreacion}}" readonly="readonly">
      </div>
      <div class="form-group">
        <label for="operario">Operario</label>
        <select class="form-control" name="operario"  required>
          @foreach ($users as $user)
              <option value="{{$user->name}}" @if($user->name == $tarea->operario) selected @endif>{{$user->name}}</option>
          @endforeach
        </select>
      </div>
      <div class="form-group">
        <label for="fechaRealizacion">Fecha Realizacion</label>
        <input type="date" class="form-control" name="fechaRealizacion" placeholder="00/00/0000" value="{{$tarea->fechaRealizacion}}">
        @error('fechaRealizacion')

          <div class="error-message">{{ $message }}</div>
        @enderror
      </div>
      <div class="form-group">
        <label for="anotacionPos">Anotacion Posterior</label>
        <input type="text" class="form-control" name="anotacionPos" placeholder="......." value="{{$tarea->anotacionPos}}">
      </div>
    <div class="form-group">
        <label for="anotacionAnt">Anotacion Anterior</label>
        <input type="text" class="form-control" name="anotacionAnt" placeholder="......." value="{{$tarea->anotacionAnt}}" readonly>
      </div>
    <div class="form-group">
        <label for="fichero">Fichero</label>
        <input type="file" class="form-control" name="fichero" placeholder="C/:....." value="{{$tarea->fichero}}">
      </div>

    <input type="submit" value="Editar" name="enviar" class="btn btn-primary">
    <a href="{{ route('tareas.index') }}" class="btn btn-warning">Cancelar</a>
</form>

@endsection