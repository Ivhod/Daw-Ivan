@extends('layouts.plantilla')

@section('cabecera')

@section('contenido')

<h1 style="text-align: center">Nosecaen S.L.</h1>
<h4> Lista de Tareas</h4>
<form action="{{route('tareas.index')}}" method="get">
  <input type="text" class="my-1"name="texto" value="{{$texto}}">
  <input type="submit" class="btn btn-primary my-1" value="Buscar">
</form>

<table class="table table-striped" style="text-align: center">
    <thead>
      <tr>
        <th hidden scope="col">ID</th>
        <th scope="col">Cliente_id</th>
        <th scope="col">User_id</th>
        <th scope="col">Nombre</th>
        <th scope="col">Telefono</th>
        <th scope="col">Descripcion</th>
        <th scope="col">Correo</th>
        <th scope="col">Direccion</th>
        <th scope="col">Poblacion</th>
        <th scope="col">Codigo Postal</th>
        <th scope="col">Provincia</th>
        <th scope="col">Estado</th>
        <th scope="col">Fecha Creacion</th>
        <th scope="col">Operario</th>
        <th scope="col">Fecha Realizacion</th>
        <th scope="col">Anotacion Posterior</th>
        <th scope="col">Anotacion Anterior</th>
        <th scope="col">Fichero</th>
        <th scope="col"></th>
        <th scope="col"></th>
      </tr>
    </thead>
    <tbody>
      @if(count($tareas)<=0)
        <tr>
          <td colspan="13">No hay resultados</td>
        </tr>
      @else

        @foreach ($tareas as $tarea)
      <tr>
        <th hidden scope="row">{{$tarea->id}}</th>
        <td>{{$tarea->cliente->nombre}}</td>
        <td>{{$tarea->user->name}}</td>
        <td>{{$tarea->nombre}}</td>
        <td>{{$tarea->telefono}}</td>
        <td>{{$tarea->descripcion}}</td>
        <td>{{$tarea->correo}}</td>
        <td>{{$tarea->direccion}}</td>
        <td>{{$tarea->poblacion}}</td>
        <td>{{$tarea->codigoPostal}}</td>
        <td>{{$tarea->provincia}}</td>
        <td>{{$tarea->estado}}</td>
        <td>{{$tarea->fechaCreacion}}</td>
        <td>{{$tarea->operario}}</td>
        <td>{{$tarea->fechaRealizacion}}</td>
        <td>{{$tarea->anotacionPos}}</td>
        <td>{{$tarea->anotacionAnt}}</td>
        <td><a href="public/images/{{$tarea->fichero}}">{{$tarea->fichero}}</a></td>
        <td><a href="{{ route('tareas.edit', $tarea->id)}}" class="btn btn-info">Editar</a></td>
        <td><a href="{{ route('tareas.destroy', $tarea->id)}}" class="btn btn-danger">Borrar</a></td>
      </tr>
      @endforeach
      @endif
    </tbody>
  </table>
  <a href="{{ route('tareas.create') }}" class="btn btn-success">Nueva Tarea</a><br><br>
  {{ $tareas->links() }}

@endsection
