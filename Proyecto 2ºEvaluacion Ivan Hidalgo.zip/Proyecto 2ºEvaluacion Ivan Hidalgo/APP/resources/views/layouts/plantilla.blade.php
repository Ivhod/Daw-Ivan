<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>Bunglebuild S.L. </title>
    <style>
        .contenido form, table {
            width: 500px;
            margin: 0 auto;

        }
        .error-message {
    color: red;
    font-size: 14px;
}

        
    </style>
</head>
<body>
    <div class="cabecera" >

        @yield('cabecera')
        @extends('layouts.app')
        @section('content')
         
    </div>
    
    <div class="contenido" >
        
    @yield('contenido')

    </div>

    <div class="pie" >

    @yield('pie')

    </div>
    @endsection
</body>
</html>