@extends('layouts.plantilla')

@section('cabecera')

@section('contenido')

<h1 style="text-align: center">Nosecaen S.L.</h1>
<h4> Lista de Usuarios</h4>
<form action="{{route('users.index')}}" method="get">
  <input type="text" class="my-1"name="texto" value="{{$texto}}">
  <input type="submit" class="btn btn-primary my-1" value="Buscar">
</form>

<table class="table table-striped" style="text-align: center">
    <thead>
      <tr>
        <th hidden scope="col">ID</th>
        <th scope="col">CIF</th>
        <th scope="col">Nombre</th>
        <th scope="col">Correo</th>
        <th scope="col">Telefono</th>
        <th scope="col">Direccion</th>
        <th scope="col">Fecha Alta</th>
        <th scope="col">Rol</th>
        <th scope="col">Password</th>
        <th scope="col"></th>
        <th scope="col"></th>
      </tr>
    </thead>
    <tbody>
      @if(count($users)<=0)
        <tr>
          <td colspan="9">No hay resultados</td>
        </tr>
      @else

        @foreach ($users as $user)
      <tr>
        <th hidden scope="row">{{$user->id}}</th>
        <td>{{$user->cif}}</td>
        <td>{{$user->name}}</td>
        <td>{{$user->email}}</td>
        <td>{{$user->telefono}}</td>
        <td>{{$user->direccion}}</td>
        <td>{{$user->fecha_alta}}</td>
        <td>{{$user->rol}}</td>
        <td>{{$user->password}}</td>
        <td><a href="{{ route('users.edit', $user->id)}}" class="btn btn-info">Editar</a></td>
        <td><a href="{{ route('users.destroy', $user->id)}}" class="btn btn-danger">Borrar</a></td>
      </tr>
      @endforeach
      @endif
    </tbody>
  </table>
  <a href="{{ route('users.create') }}" class="btn btn-success">Nuevo Usuario</a><br><br>
  {{ $users->links() }}

@endsection
