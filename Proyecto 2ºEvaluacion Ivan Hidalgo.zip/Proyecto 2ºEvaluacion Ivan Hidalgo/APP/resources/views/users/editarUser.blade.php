@extends('layouts.plantilla')

@section('cabecera')

    
@endsection

@section('contenido')
<h1 style="text-align: center">Editar Usuario</h1>
<form action="/users/{{$user->id}}" method="post">
    @method('PUT')
    <div class="form-group">
        <label for="cif">CIF</label>
        <input type="text" class="form-control" name="cif" placeholder="Introduce CIF" value="{{$user->cif}}">
        @error('cif')
          <div class="error-message">{{ $message }}</div>
        @enderror
      </div>
      {{csrf_field()}}

      <div class="form-group">
        <label for="name">Nombre</label>
        <input type="text" class="form-control" name="name"  placeholder="Introduce Nombre" value="{{$user->name}}">
      </div>
      <div class="form-group">
        <label for="email">Correo</label>
        <input type="text" class="form-control" name="email" placeholder="Introduce Correo" value="{{$user->email}}">
      </div>
      <div class="form-group">
        <label for="telefono">Telefono</label>
        <input type="text" class="form-control" name="telefono" placeholder="Introduce Telefono" value="{{$user->telefono}}" pattern="[0-9]*" maxlength="10">
        @error('telefono')
          <div class="error-message">{{ $message }}</div>
        @enderror
      </div>
      <div class="form-group">
        <label for="direccion">Direccion</label>
        <input type="text" class="form-control" name="direccion" placeholder="Introduce Direccion" value="{{$user->direccion}}">
      </div>
      <div class="form-group">
        <label for="fecha_alta">Fecha Alta</label>
        <input type="text" class="form-control" name="fecha_alta" placeholder="00/00/0000" value="{{$user->fecha_alta}}" readonly>
      </div>
      <div class="form-group">
        <label for="rol">Rol</label>
        <select class="form-control" name="rol"  required>
          <option value="admin" @if($user->rol == "admin") selected @endif>Admin</option>
          <option value="operario" @if($user->rol == "operario") selected @endif>Operario</option>
        </select>
      </div>
      <div class="form-group">
        <label for="password">Password</label>
        <input type="password" class="form-control" name="password" placeholder="********" value="{{$user->password}}">
      </div>

    <input type="submit" value="Editar" name="enviar" class="btn btn-primary">
    <a href="{{ route('users.index') }}" class="btn btn-warning">Cancelar</a>
</form>

@endsection